#!/bin/bash

python3 26.py $1
