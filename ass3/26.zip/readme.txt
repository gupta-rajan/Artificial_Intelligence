Travelling Salesman Problem
----------------------------------------------------------------------------------
How to run the code?
1. Open bash in same directory folder in which all files are in.
2. Type in bash terminal : bash run.sh <file-name>, where <file-name> is name of the input file. e.g. euc_100,noneuc_100
3. The output will be displayed in bash terminal itself.

-----------------------------------------------------------------------------------
Output: (output is printed in bash terminal)
Prints the best possible path for TSP in which name alloted to each coordinate will be printed.
The cost of the best possible path.
Time taken for the greedy algorithm and simulated annealing implemented.
------------------------------------------------------------------------------------
Thank you!