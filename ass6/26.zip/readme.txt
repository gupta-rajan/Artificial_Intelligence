____________Assignment -6_______________
_________________________________________

1. Extract the given folder in linux environment.
2. Run 'make' command .
3. Use the following command to run the minimax_bot.so against RandomBot.so :

" ./bin/Desdemona ./bots/RandomBot/RandomBot.so ./bots/minimax_bot/minimax_bot.so"

4. Use the following command to run the AB_bot.so against RandomBot.so:

" ./bin/Desdemona ./bots/RandomBot/RandomBot.so ./bots/AB_bot/AB_bot.so"


