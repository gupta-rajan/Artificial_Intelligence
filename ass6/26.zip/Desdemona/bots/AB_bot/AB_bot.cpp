/*
* @file botTemplate.cpp
* @author Arun Tejasvi Chaganty <arunchaganty@gmail.com>
* @date 2010-02-04
* Template for users to create their own bots
*/

#include "Othello.h"
#include "OthelloBoard.h"
#include "OthelloPlayer.h"
#include <cstdlib>
#include<climits>
using namespace std;
using namespace Desdemona;

class MyBot: public OthelloPlayer
{
    public:
        /**
         * Initialisation routines here
         * This could do anything from open up a cache of "best moves" to
         * spawning a background processing thread. 
         */
        MyBot( Turn turn );

        /**
         * Play something 
         */
        virtual Move play(const OthelloBoard &board);   //virtual is pre-defined for the base class and used to avoid clashing.
        int AB_minimax(OthelloBoard &board, int depth, Move move, Turn turn, int Min, int Max);  //Move is (x,y) coordinate, turn is red or black.
        int heuristic(OthelloBoard &board);
        
    private:
};

MyBot::MyBot( Turn turn )
    : OthelloPlayer( turn )
{
}

Move MyBot::play( const OthelloBoard& board )
{
    list<Move> moves = board.getValidMoves( turn );
    // int randNo = rand() % moves.size();
    // list<Move>::iterator it = moves.begin();

    // return *it;

    Move best_move = *moves.begin();
    int best_val = INT_MIN;

    int depth = 3;
    int Min = INT_MIN;
    int Max = INT_MAX;
    // while(1){
        for(Move m:moves){

            OthelloBoard othello_board = OthelloBoard(board);
            int eval_val = AB_minimax(othello_board,depth,m,turn,Min,Max);

            if(eval_val>best_val){
                best_val = eval_val;
                best_move = m;
            }

            //time up condition
            if (eval_val == INT_MIN){
                return best_move;
            }
        }
    //     depth++;
    //     if(depth == 3){
    //         break;
    //     }
    // }

    return best_move;
}

int MyBot::AB_minimax(OthelloBoard &board, int depth, Move move, Turn turn, int Min, int Max){

    OthelloBoard othello_board = OthelloBoard(board);
    othello_board.makeMove(turn,move);
    list<Move> valid_moves = othello_board.getValidMoves(other(turn));

    if(depth==0){
        return heuristic(othello_board);
    }

    int opt_val;

    if(this->turn == turn){
        opt_val = INT_MAX;
        for(Move m: valid_moves){
            opt_val = min(opt_val,AB_minimax(othello_board,depth-1,m,other(turn),Min,Max));
            if(Min >= min(Max, opt_val)){
                break;
            }
        }
    }
    else{
        opt_val = INT_MIN;
        for(Move m: valid_moves){
            opt_val = max(opt_val,AB_minimax(othello_board,depth-1,m,other(turn),Min,Max));
            if(Max<= max(Min,opt_val)){
                break;
            }
        }
    }
    return opt_val;
}

int MyBot::heuristic(OthelloBoard &board){
    // if(this->turn == turn){
    //     return 100*((board.getBlackCount()-board.getRedCount())/(board.getRedCount()+board.getBlackCount()));
    // }
    // else{
    //     return 100*((board.getRedCount()-board.getBlackCount())/(board.getRedCount()+board.getBlackCount()));
    // }

    int optimal_board[8][8]= {{4,-3,2,2,2,2,-3,4},
                            {-3,-4,-1,-1,-1,-1,-4,-3},
                            {2,-1,1,0,0,1,-1,2},
                            {2,-1,0,1,1,0,-1,2},
                            {2,-1,0,1,1,0,-1,2},
                            {2,-1,1,0,0,1,-1,2},
                            {-3,-4,-1,-1,-1,-1,-4,-3},
                            {4,-3,2,2,2,2,-3,4}  };

    int h_value = 0;

    for(int i=0;i<8;i++){
        for(int j=0;j<8;j++){
            if(board.get(i,j) == turn){
                h_value+= optimal_board[i][j];
            }
            else if(board.get(i,j)==other(turn)){
                h_value-= optimal_board[i][j];
            }
        }
    }
    return h_value;
}

// The following lines are _very_ important to create a bot module for Desdemona

extern "C" {
    OthelloPlayer* createBot( Turn turn )
    {
        return new MyBot( turn );
    }

    void destroyBot( OthelloPlayer* bot )
    {
        delete bot;
    }
}