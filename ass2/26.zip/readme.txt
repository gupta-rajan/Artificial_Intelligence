Blocks world Domain
__________________________________________________________________________________
Note: the program doesn't use any command line argument.
----------------------------------------------------------------------------------
What is there in input.txt?
1. First line gives the no. of test cases.
2. Initial state is given by Stack elements given in each line where "," represents push and new line means new Stack
3. Empty line represent initial state is completed now take final state.
4. "-" represents this test case input is taken and new test case begins.

-----------------------------------------------------------------------------------
How to run the code?
1. Run 26.py 
2. Enter any integer from 1 to 3 to run the heuristic function 1,2,3 respectively.

-----------------------------------------------------------------------------------
Output: (output is printed in terminal)
Prints Initial state then Goal state (where "@" represents stack).
The goal is reachable or not.
No. of states explored.
Path followed by the given heuristic function.
Time taken for the hill climbing algorithm by given heuristic function.
------------------------------------------------------------------------------------
Thank you!